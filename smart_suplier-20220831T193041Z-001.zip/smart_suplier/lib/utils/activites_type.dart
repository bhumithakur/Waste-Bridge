import 'package:smart_bin/constant.dart';

Map<String,dynamic>alertType={
  'ALERT':{
    'color':kRedColor,
    'image':'assets/icons/alert.svg'
  }
};