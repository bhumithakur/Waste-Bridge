package com.example.smart_bin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
