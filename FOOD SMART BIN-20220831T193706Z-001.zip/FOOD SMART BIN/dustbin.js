function add() {

    //  document.getElementById("d_box_cap").style.transform = "rotate(-45 + deg)";
    // document.getElementById("d_box_cap").style.transformOrigin = "top left";
    var weight;
    weight = prompt("Enter the amount of waste between 1 to 100kg ");
    if (weight >= 1 && weight <= 100) {
        document.getElementById("d_box1").style.height = weight + '%';
    } else {
        weight = "INVALID WEIGHT ";
    }
    alert(" Current Weight of Dustbin: " + weight);
}